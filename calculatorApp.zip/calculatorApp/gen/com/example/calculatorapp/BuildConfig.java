/** Automatically generated file. DO NOT MODIFY */
package com.example.calculatorapp;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}